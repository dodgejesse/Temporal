package edu.berkeley.nlp;

/**
 * @author Dan Klein
 */
public class Test<E> {
  public static void main(String[] args) {
    System.out.println("Test PASSED.");
  }
}
